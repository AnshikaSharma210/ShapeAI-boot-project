import React from "react";

function Boot() {
  return (
    <div className="note">
      <h1>React JS Bootcamp</h1>
      <p>Last day of bootcamp.It was fun learning everything.</p>
    </div>
  );
}

export default Boot;
